
function validateForm() {
    let fname = document.reg_form.fname;
    let lname = document.reg_form.lname;
    let address = document.reg_form.address;
    let gender = document.reg_form.gender;
    let email = document.reg_form.email;
    let mobile = document.reg_form.mobile;
    let course = document.reg_form.course;

    if (fname.value.length <= 0) {
        alert("Name is required");
        fname.focus();
        return false;
    }
    if (lname.value.length <= 0) {
        alert("LastbName is required");
        lname.focus();
        return false;
    }
    if (address.value.length <= 0) {
        alert("Address is required");
        address.focus();
        return false;
    }
    if (gender.value.length <= 0) {
        alert("Gender is required");
        gender.focus();
        return false;
    }
    if (email.value.length <= 0) {
        alert("Email is required");
        email.focus();
        return false;
    }
    if (mobile.value.length <= 0) {
        alert("Mobile nummber is required");
        mobile.focus();
        return false;
    }
    if (course.value.length <= 0) {
        alert("Course is required");
        course.focus();
        return false;
    }
    return false;
}